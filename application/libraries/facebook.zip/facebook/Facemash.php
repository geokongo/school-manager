<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
if ( session_status() == PHP_SESSION_NONE ) {
session_start();
}
 
// Autoload the required files
require_once( APPPATH . 'libraries/facebook/autoload.php' );

use Facebook\Entities\FacebookApp;

$id = '1563588553853090';
$secret = '21ae87bddc5bc508d91ccace40db7b63';

$facebookApp = new FacebookApp($id, $secret);

use Facebook\FacebookClient;

$facebookClient = new FacebookClient();

use Facebook\Helpers\FacebookRedirectLoginHelper;


$helper = new FacebookRedirectLoginHelper($facebookApp);
$permissions = ['email', 'user_likes']; // optional
$loginUrl = $helper->getLoginUrl('http://www.schoolmanager.or.ke/settings/addNewUser', $permissions);

echo '<a href="' . $loginUrl . '">Log in with Facebook!</a>';

# login-callback.php
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

use Facebook\Helpers\FacebookCanvasLoginHelper;

try {
  $accessToken = $helper->getAccessToken($facebookClient);
} catch(FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
} catch(FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
}

if (isset($accessToken)) {
  // Logged in
}

echo $accessToken;
 
 
